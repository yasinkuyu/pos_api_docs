package com.est;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Locale;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import com.sun.net.ssl.KeyManager;
import com.sun.net.ssl.SSLContext;
import com.sun.net.ssl.TrustManager;
import com.sun.net.ssl.X509TrustManager;

public class jpay {
	private static String ApiVersion = "2.07";
	public Document indoc = new Document();
	public Document outdoc = new Document();
	public String reqString = "";
	public Element rootel = new Element("CC5Request");
	public ByteArrayOutputStream outStream = new ByteArrayOutputStream();
	public ByteArrayInputStream outResp = null;
	public int timeout = 90; // seconds
	private String logfilename = "jpaylog.txt";

	public String orderid = "";
	public String groupid = "";
	public String response = "";
	public String authcode = "";
	public String hostrefnum = "";
	public String procreturncode = "";
	public String transid = "";
	public String errmsg = "";
	public Element resextra = new Element("Extra");
	public boolean debug = false;
	public boolean forceSSLTrust = false;

	public jpay() {
		setMode("P");
	}

	public void logger(String line) {
		PrintWriter logfile;
		try {
			if (debug) {
				logfile = new PrintWriter(new OutputStreamWriter(
						new FileOutputStream(logfilename, true), "ISO8859-9"));
				logfile.write(line + "\r\n");
				logfile.close();
			}
		} catch (Exception e) {
			System.out.println("Jpay Logging Unavailable!");
		}
	}

	public void logger(ByteArrayOutputStream b1) {
		try {
			if (debug) {
				FileOutputStream logfile = new FileOutputStream(logfilename,
						true);
				b1.writeTo(logfile);
				logfile.close();
			}
		} catch (Exception e) {
			System.out.println("Jpay Logging Unavailable!");
		}
	}

	/**
	 * Siparis numarasini verir.
	 * @since 1.0 
	 * @return Siparis numarasini verir.
	 */

	public String getOrderId() {
		try {
			return orderid;
		} catch (Exception e) {
			// logger("getOrderId Exception" + e);
			return "";
		}

	}

	/**
	 * Grup numarasini verir.
	 * @since 1.0
	 * @return Grup numarasini verir.
	 */
	public String getGroupId() {
		try {
			return groupid;
		} catch (Exception e) {
			// logger("getGroupId Exception" + e);
			return "";
		}

	}

	/**
	 * Islem sonucunu verir.
	 * @since 1.0
	 * @return Islem sonucunu verir. Approved Declined Error
	 */
	public String getResponse() {
		try {
			return response;
		} catch (Exception e) {
			// logger("getResponse Exception" + e);
			return "";
		}

	}

	/**
	 * Provizyon numarasini verir.
	 * @since 1.0
	 * @return Provizyon numarasini verir.
	 */
	public String getAuthCode() {
		try {
			return authcode;
		} catch (Exception e) {
			// logger("getAuthCode Exception" + e);
			return "";
		}

	}

	/**
	 * Islem referans numarasini verir.
	 * @since 1.0
	 * @return Islem referans numarasini verir.
	 */
	public String getHostRefNum() {
		try {
			return hostrefnum;
		} catch (Exception e) {
			// logger("getHostRefNum Exception" + e);
			return "";
		}

	}

	/**
	 * Islem sonuc kodunu verir.
	 * @since 1.0
	 * @return Islem sonuc kodunu verir.
	 */
	public String getProcReturnCode() {
		try {
			return procreturncode;
		} catch (Exception e) {
			// logger("getProcReturnCode Exception" + e);
			return "";
		}

	}

	/**
	 * Islem numarasini verir.
	 * @since 1.0
	 * @return Islem numarasini verir.
	 */
	public String getTransId() {
		try {
			return transid;
		} catch (Exception e) {
			// logger("getTransId Exception" + e);
			return "";
		}

	}

	/**
	 * Hata mesajini verir.
	 * @since 1.0
	 * @return Hata mesajini verir.
	 */
	public String getErrMsg() {
		try {
			return errmsg;
		} catch (Exception e) {
			// logger("getErrMsg Exception" + e);
			return "";
		}

	}

	/**
	 * Yeni parametreler gonderebilmek icin kullanilir.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setParameter(String name, String value) {
		try {
			Element el = new Element(name);
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setParameter Exception" + e);
			return -1;
		}

	}

	/**
	 * Kullanici adini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setName(String value) {
		try {
			Element el = new Element("Name");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setName Exception" + e);
			return -1;
		}

	}

	/**
	 * Sifreyi girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setPassword(String value) {
		try {
			Element el = new Element("Password");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setPassword Exception" + e);
			return -1;
		}

	}

	/**
	 * Uyeisyeri numarasini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setClientId(String value) {
		try {
			Element el = new Element("ClientId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);

			Element ela = new Element("ApiVersion");
			ela.addContent(unicode2uniturk(ApiVersion));
			rootel.addContent(ela);

			return 1;
		} catch (Exception e) {
			// logger("setClientId Exception" + e);
			return -1;
		}
	}

	/**
	 * Alisveris yapan musterinin numarasini girmek icin.(Opsiyonel)
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setIPAddress(String value) {
		try {
			Element el = new Element("IPAddress");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setIPAddress Exception" + e);
			return -1;
		}

	}

	/**
	 * �slem modunu girmek icin. Gercek islemler icib P Test icin T girilmeli.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setMode(String value) {
		try {
			Element el = new Element("Mode");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setMode Exception" + e);
			return -1;
		}
	}

	/**
	 * Siparis numarasini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setOrderId(String value) {
		try {
			Element el = new Element("OrderId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setOrderId Exception" + e);
			return -1;
		}

	}

	/**
	 * Grup numarasini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setGroupId(String value) {
		try {
			Element el = new Element("GroupId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setGroupId Exception" + e);
			return -1;
		}

	}

	/**
	 * �slem numarasini girmek icin.(Opsiyonel)
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setTransId(String value) {
		try {
			Element el = new Element("TransId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setTransId Exception" + e);
			return -1;
		}

	}

	/**
	 * Musterinin numarasini girmek icin.(Opsiyonel)
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setUserId(String value) {
		try {
			Element el = new Element("UserId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setUserId Exception" + e);
			return -1;
		}

	}

	/**
	 * �slem tipini girmek icin.PreAuth,Auth,PostAuth,Void,Credit degerlerini
	 * alabilir.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setType(String value) {
		try {
			Element el = new Element("Type");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setType Exception" + e);
			return -1;
		}

	}

	/**
	 * Kredikarti numarasini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setNumber(String value) {
		try {
			Element el = new Element("Number");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setNumber Exception" + e);
			return -1;
		}

	}

	/**
	 * Kredikarti sonkullanma tarihini girmek icin. MM/YY formatinda
	 * yazilmalidir.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setExpires(String value) {
		try {
			Element el = new Element("Expires");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setExpires Exception" + e);
			return -1;
		}

	}

	/**
	 * CVV numarasini girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setCvv2Val(String value) {
		try {
			Element el = new Element("Cvv2Val");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCvv2Val Exception" + e);
			return -1;
		}

	}

	/**
	 * Toplam tutari girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setTotal(String value) {
		try {
			Element el = new Element("Total");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setTotal Exception" + e);
			return -1;
		}

	}

	/**
	 * Para birimini girmek icin. TL icin 792 olmalidir.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setCurrency(String value) {
		try {
			Element el = new Element("Currency");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * PayerTxnId gondermek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setPayerTxnId(String value) {
		try {
			Element el = new Element("PayerTxnId");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * PayerAuthenticationCode gondermek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setPayerAuthenticationCode(String value) {
		try {
			Element el = new Element("PayerAuthenticationCode");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * PayerSecurityLevel gondermek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setPayerSecurityLevel(String value) {
		try {
			Element el = new Element("PayerSecurityLevel");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * CardholderPresentCode gondermek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setCardholderPresentCode(String value) {
		try {
			Element el = new Element("CardholderPresentCode");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * Email adresini gondermek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setEmail(String value) {
		try {
			Element el = new Element("Email");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setCurrency Exception" + e);
			return -1;
		}

	}

	/**
	 * Bankaniz tarafindan destekleniyorsa taksit bilgisini gondermek
	 * icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setTaksit(String value) {
		try {
			Element el = new Element("Taksit");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setTaksit Exception" + e);
			return -1;
		}
	}

	/**
	 * comments bilgisini gondermek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setComments(String value) {
		try {
			Element el = new Element("Comments");
			el.addContent(unicode2uniturk(value));
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setComments Exception" + e);
			return -1;
		}
	}

	/**
	 * Periodik islem gondermek icin.(Opsiyonel)
	 * <p>
	 * value1 �slem tipi 0 , 1 value2 Toplam odeme sayisi value3 Siparis
	 * Frekansi value4 Siparis Frekans araligi
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setPbOrder(String value1, String value2, String value3,
			String value4) {
		try {
			Element el = new Element("PbOrder");
			Element el1 = new Element("OrderType");
			Element el2 = new Element("TotalNumberPayments");
			Element el3 = new Element("OrderFrequencyCycle");
			Element el4 = new Element("OrderFrequencyInterval");
			el1.addContent(value1);
			el2.addContent(value2);
			el3.addContent(value3);
			el4.addContent(value4);
			el.addContent(el1).addContent(el2).addContent(el3).addContent(el4);
			rootel.addContent(el);
			return 1;
		} catch (Exception e) {
			// logger("setPbOrder Exception" + e);
			return -1;
		}

	}

	/**
	 * Periodik islem gondermek icin.(Opsiyonel)
	 * <p>
	 * value1 Urun numarasi
	 * <p>
	 * value2 Urun kodu
	 * <p>
	 * value3 Adet
	 * <p>
	 * value4 Aciklama
	 * <p>
	 * value5 Kod
	 * <p>
	 * value6 Fiyat
	 * <p>
	 * value7 Tutar
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setOrderItem(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7) {
		try {
			// OrderItemlist yoksa yarat varsa ekle

			if (rootel.getChild("OrderItemList") == null) {
				Element elfirstlist = new Element("OrderItemList");
				rootel.addContent(elfirstlist);

			}

			Element elolist = rootel.getChild("OrderItemList");

			elolist.detach();

			Element el = new Element("OrderItem");
			Element el1 = new Element("ItemNumber");
			Element el2 = new Element("ProductCode");
			Element el3 = new Element("Qty");
			Element el4 = new Element("Desc");
			Element el5 = new Element("Id");
			Element el6 = new Element("Price");
			Element el7 = new Element("Total");

			el1.addContent(value1);
			el2.addContent(value2);
			el3.addContent(value3);
			el4.addContent(value4);
			el5.addContent(value5);
			el6.addContent(value6);
			el7.addContent(value7);

			el.addContent(el1).addContent(el2).addContent(el3).addContent(el4)
					.addContent(el5).addContent(el6).addContent(el7);
			elolist.addContent(el);
			rootel.addContent(elolist);

			return 1;
		} catch (Exception e) {
			// logger("setOrderItem Exception" + e);
			return -1;
		}

	}

	/**
	 * Fatura bilgisine isim girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBName(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Name");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBName Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine birinci adres satirini girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBStreet1(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Street1");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBStreet1 Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine ikinci adres satirini girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBStreet2(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Street2");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBStreet2 Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine ucuncu adres satirini girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBStreet3(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Street3");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBStreet3 Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine sehir girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBCity(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("City");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBCity Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine state girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBStateProv(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("StateProv");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBStateProv Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine posta kodu girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBPostalCode(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("PostalCode");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBPostalCode Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine ulke kodu girmek icin.Turkiye 792.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBCountry(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Country");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBCountry Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine firma girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBCompany(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("Company");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBCompany Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine telefon girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBTelVoice(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("TelVoice");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBTelVoice Exception" + e);
			return -1;
		}
	}

	/**
	 * Fatura bilgisine fax girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setBTelFax(String value) {
		try {
			if (rootel.getChild("BillTo") == null) {
				Element elfirstbillto = new Element("BillTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("BillTo");

			elbillto.detach();

			Element el = new Element("TelFaxme");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setBTelFax Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine isim girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSName(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Name");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSName Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine birinci adres satirini girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSStreet1(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Street1");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSStreet1 Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine ikinci adres satirini girmek icin.(Opsiyonel)
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSStreet2(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Street2");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSStreet2 Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine ucuncu adres satirini girmek icin.(Opsiyonel)
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSStreet3(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Street3");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSStreet3 Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine sehir girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSCity(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("City");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSCity Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine state girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSStateProv(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("StateProv");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSStateProv Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine posta kodu girmek icin.
	 * @since 1.0
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSPostalCode(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("PostalCode");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSPostalCode Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine ulke kodu girmek icin.Turkiye icin 792
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSCountry(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Country");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSCountry Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine firma girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSCompany(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("Company");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSCompany Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine telefon girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSTelVoice(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("TelVoice");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSTelVoice Exception" + e);
			return -1;
		}
	}

	/**
	 * Teslimat bilgisine fax girmek icin.
	 * 
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setSTelFax(String value) {
		try {
			if (rootel.getChild("ShipTo") == null) {
				Element elfirstbillto = new Element("ShipTo");
				rootel.addContent(elfirstbillto);
			}
			Element elbillto = rootel.getChild("ShipTo");

			elbillto.detach();

			Element el = new Element("TelFax");
			el.addContent(unicode2uniturk(value));
			elbillto.addContent(el);
			rootel.addContent(elbillto);
			return 1;

		} catch (Exception e) {
			// logger("setSTelFax Exception" + e);
			return -1;
		}
	}

	public void setDebug(boolean value) {
		debug = value;
		logger("Logging on \r\n");
	}

	/**
	 * Gerekirse ekstra parametre girmek icin.
	 * <p>
	 * value1 parametrenin ismi
	 * <p>
	 * value2 parametrenin degeri
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return Basarili ise 1 degilse -1 doner.
	 */
	public int setExtra(String value1, String value2) {
		try {
			// Extra yoksa yarat varsa ekle

			if (rootel.getChild("Extra") == null) {
				Element elfirstextra = new Element("Extra");
				rootel.addContent(elfirstextra);

			}

			Element elextra = rootel.getChild("Extra");

			elextra.detach();

			Element el = new Element(value1);

			el.addContent(value2);

			elextra.addContent(el);
			rootel.addContent(elextra);

			return 1;
		} catch (Exception e) {
			// logger("setExtra Exception" + e);
			return -1;
		}

	}

	/**
	 * Gerekirse ekstra parametre almak icin.
	 * <p>
	 * value1 parametrenin ismi
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return parametrenin degeri.
	 */
	public String getExtra(String value1) {
		try {
			// Extra yoksa yarat varsa ekle
			Element cc5response = outdoc.getRootElement();
			if (cc5response.getName().equals("CC5Response")) {
				if (cc5response.getChild("Extra") != null) {
					Element elextra = cc5response.getChild("Extra");
					return getChildValue(elextra, value1.toUpperCase(Locale.US));
				}
			}
			return "";
		} catch (Exception e) {
			// logger("getExtra Exception" + e);
			return "";
		}

	}

	private String getChildValue(Element parentName, String childName) {

		try {
			return parentName.getChild(childName).getText();
		} catch (Exception e) {
			logger("getChildValue " + childName + " " + e + "\r\n");
			return ("");
		}
	}

	private ByteArrayOutputStream fixHTTPStream(ByteArrayOutputStream in) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] inArr = in.toByteArray();

		for (int i = 0; i < inArr.length; i++) {
			int b1 = inArr[i];
			if (b1 == '+') {
				out.write('%');
				out.write('2');
				out.write('B');
			} else if (b1 == '%') {
				out.write('%');
				out.write('2');
				out.write('5');
			} else if (b1 == ' ') {
				out.write('+');
			}

			else {
				out.write(b1);
			}
		}

		return out;
	}

	/**
	 * Gerekirse ekstra parametre almak icin.
	 * 
	 * @param host
	 *            sanal pos sunucusunun host adi
	 * @param port
	 *            sanal pos sunucusunun port numarasi
	 * @param path
	 *            sanal pos sunucusunun adresi
	 * 
	 * @since 1.0
	 * 
	 * 
	 * @return parametrenin degeri.
	 */
	public int processTransaction(String host, int port, String path) {
		try {
			indoc = new Document(rootel);

			/*
			 * XMLOutputter outputter = new XMLOutputter(" ",true,"ISO-8859-1");
			 * //XMLOutputter outputter = new XMLOutputter(" ",true); Oracle
			 * kullananlar i�in
			 */

			org.jdom.output.Format myformat = org.jdom.output.Format
					.getPrettyFormat();
			myformat.setEncoding("ISO-8859-9");
			myformat.setExpandEmptyElements(true);
			XMLOutputter outputter = new XMLOutputter(myformat);

			ByteArrayOutputStream body = new ByteArrayOutputStream();
			outputter.output(indoc, body);
			logger(body);

			body = fixHTTPStream(body);

			// if kontrol
			int ret1 = spinrequest(host, port, path, body);
			if (ret1 > 0) {
				Element cc5response = outdoc.getRootElement();
				if (cc5response.getName().equals("CC5Response")) {

					orderid = getChildValue(cc5response, "OrderId");
					groupid = getChildValue(cc5response, "GroupId");
					authcode = getChildValue(cc5response, "AuthCode");
					response = getChildValue(cc5response, "Response");
					hostrefnum = getChildValue(cc5response, "HostRefNum");
					procreturncode = getChildValue(cc5response,
							"ProcReturnCode");
					transid = getChildValue(cc5response, "TransId");
					errmsg = getChildValue(cc5response, "ErrMsg");

					return 1;
				} else {
					return -1;
				}
			} else {
				return -2;
			}

		} catch (Exception e) {
			logger("processTransaction Exception " + e);
			e.printStackTrace();
			return -1;
		}
	}

	public int spinrequest(String host, int port, String path,
			ByteArrayOutputStream body) {
		try {
			System.setProperty("java.protocol.handler.pkgs",
					"com.sun.net.ssl.internal.www.protocol");
			Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

			SSLSocketFactory factory;

			if (forceSSLTrust) {
				factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			} else {
				try {
					X509TrustManager tm = new eX509TrustManager3();
					KeyManager[] km = null;
					TrustManager[] tma = { tm };

					SSLContext sc = SSLContext.getInstance("SSL");
					sc.init(km, tma, new SecureRandom());
					factory = sc.getSocketFactory();
				} catch (Exception e) {
					errmsg = e.getMessage();
					return -3;
				}
			}

			SSLSocket socket = (SSLSocket) factory.createSocket(host, port);
			// logger("\nAfter create socket ");

			try {
				socket.setSoTimeout(timeout * 1000);
				socket.startHandshake();

				// logger("after startHandshake ");

				OutputStream out = socket.getOutputStream();

				String head = "POST " + path + " HTTP/1.1\r\n";
				head += "Host: " + host + "\r\n";
				head += "Content-Type: application/x-www-form-urlencoded\r\n";

				head += "Content-length: " + (body.size() + 5) + "\r\n";
				head += "\r\n";
				head += "DATA=";
				out.write(head.getBytes("ISO8859_1"), 0, head.length());
				// data
				body.writeTo(out);
				out.flush();

				socket.setSoTimeout(timeout * 1000);
				/* read response */
				BufferedReader outBuf = new BufferedReader(
						new InputStreamReader(socket.getInputStream(),
								"ISO8859_1"));

				String inputLine;
				int conlen = 10000; // max xml size

				// logger("********** Response Header *********\r\n");

				while ((inputLine = outBuf.readLine()) != null) {
					// logger(inputLine);
					if (inputLine.toUpperCase(Locale.US).indexOf(
							"CONTENT-LENGTH:") == 0) {
						conlen = Integer.parseInt(inputLine.substring(16));
					}
					if ("".equals(inputLine))
						break;
				}
				// logger("After Header Conlen = "+conlen +"\r\n");
				// logger("-----------------------Response
				// Begin--------------------------------------------\n");
				// clean CR LF space before XML
				int b1;
				do {
					b1 = outBuf.read();
					conlen--;
				} while ((b1 >= 0) && (b1 <= 32)); // space 32 CR 13 LF 10
				conlen++;

				byte tmpByteArr[] = new byte[conlen + 1];
				int outsize = 0; // rewind buffer
				do {
					tmpByteArr[outsize++] = (byte) b1;
					// logger(""+b1);
					if (outsize >= conlen)
						break;
					b1 = outBuf.read();
				} while (b1 > 0);
				// write response

				outResp = new ByteArrayInputStream(tmpByteArr, 0, outsize);
				// outResp = fixApiserverXml(outResp);
				outdoc = getXMLdoc(outResp);

				// outResp = new ByteArrayInputStream(tmpByteArr,0,outsize);
				// logger("-----------------------Response
				// End----------------------------------------------\n");

				outBuf.close();
				out.close();
				socket.close();

				return outsize;
			} catch (IOException ioexcp) {
				logger("\nTimeout\n" + ioexcp.getMessage() + " \n");
				errmsg = "IO Error :" + ioexcp.getMessage();
				return -1;
			}

		} catch (Exception e) {
			logger("\nSpinRequest Exception: " + e.getMessage() + " \n");
			errmsg = "Connection Error : " + e.getMessage();
			return -2;
		}
	}

	public Document getXMLdoc(java.io.InputStream isrt) {
		// process XML message and document controls
		try {
			SAXBuilder builder = new SAXBuilder();
			return (builder.build(isrt));
		} catch (Exception e) {
			e.printStackTrace();
			// logger(ccD,"getXMLdoc " + e.getMessage() + " \n");
			logger("getXMLdoc " + e.getMessage() + " \n");
			return null;
		}
	}

	public String unicode2uniturk(java.lang.String newMessage) {
		// Generates Unicode from tur8unicode
		char chWrong[] = { 254, 222, 240, 208, 253, 221 };
		char chRight[] = { 351, 350, 287, 286, 305, 304 };
		int i;
		if (newMessage == null)
			return null;
		for (i = 0; i <= 5; i++)
			newMessage = newMessage.replace(chWrong[i], chRight[i]);

		return newMessage;
	}

	public String getLogfilename() {
		return logfilename;
	}

	public void setLogfilename(String logfilename) {
		this.logfilename = logfilename;
	}

	public void setEffectiveClientid(String EffectiveClientid) {
		Element el = new Element("EffectiveClientId");
		el.addContent(unicode2uniturk(EffectiveClientid));
		rootel.addContent(el);
	}

	/**
	 * Veritabani karakter cevrimi icin
	 * 
	 * @param newMessage
	 */
	/*
	 * public String uniturk2unicode(java.lang.String newMessage) {
	 * 
	 * //Generates Unicode from tur8unicode char chWrong[] =
	 * {254,222,240,208,253,221}; char chRight[] = {351,350,287,286,305,304};
	 * int i; if (newMessage==null) return null; for (i = 0; i <= 5; i++)
	 * newMessage = newMessage.replace(chWrong[i],chRight[i]);
	 * 
	 * return newMessage; }
	 */

	/*
	 * private ByteArrayInputStream fixApiserverXml(ByteArrayInputStream in) {
	 * try{ ByteArrayOutputStream out= new ByteArrayOutputStream();
	 * 
	 * BufferedReader inBuf = new BufferedReader( new
	 * InputStreamReader(in,"ISO8859-1"));
	 * 
	 * String line=inBuf.readLine(); while ( line!=null ){ if ( line.indexOf("<?xml
	 * version=\"1.0\" encoding=\"ISO-8859-9\"?>") >= 0 ) line="<?xml
	 * version=\"1.0\" encoding=\"ISO-8859-1\"?>";
	 * 
	 * line+="\r\n"; out.write(line.getBytes("ISO8859-1"));
	 * line=inBuf.readLine(); }
	 * 
	 * //out.writeTo(cc5asD.BA); //debug output
	 * 
	 * return ( new ByteArrayInputStream(out.toByteArray()) ); } catch
	 * (Exception e){ return null; } }
	 * 
	 */

} // End jpay class

