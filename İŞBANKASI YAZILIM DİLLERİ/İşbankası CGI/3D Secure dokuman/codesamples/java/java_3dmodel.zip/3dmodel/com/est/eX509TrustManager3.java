package com.est;

import com.sun.net.ssl.X509TrustManager;

//SSL connection certificate checks
public class eX509TrustManager3 implements X509TrustManager {
	public boolean isClientTrusted(java.security.cert.X509Certificate[] chain) {
		return true;
	}

	public boolean isServerTrusted(java.security.cert.X509Certificate[] chain) {
		return true;
	}

	public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		return null;
	}
}
